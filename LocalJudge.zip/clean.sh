rm *.dat
sleep 0.5s
